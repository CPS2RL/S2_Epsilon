#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ "${DRY_RUN:-0}" != "1" && "$EUID" -ne 0 ]]; then
  echo 'Run collection with sudo -E (or use DRY_RUN=1 to validate inputs)' >&2
  exit 2
fi
if [[ "${DRY_RUN:-0}" != "1" ]]; then
  if ! grep -q '^CONFIG_PREEMPT_RT=y$' "/boot/config-$(uname -r)"; then
    echo 'ERROR: running kernel has not been verified as PREEMPT_RT' >&2
    exit 2
  fi
  gcc -O2 -pthread -Wall -Wextra benchmark.c -lm -o pi_benchmark
fi
python3 runner_200.py
