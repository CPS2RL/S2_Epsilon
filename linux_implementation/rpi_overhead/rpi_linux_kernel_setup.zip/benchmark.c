#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <pthread.h>
#include <sched.h>
#include <time.h>
#include <unistd.h>
#include <stdint.h>
#include <errno.h>
#include <stdatomic.h>
#define MAX_TASKS 64
#define NS 1000000000LL
struct task {int id,rank; double C,T,epslo,epshi,delta; pthread_t thread; volatile uint64_t work_sink; unsigned long jobs,miss; double rand_ns; unsigned long rand_calls,attempts,fallbacks;};
static struct task tasks[MAX_TASKS]; static int n,mode,cpu=1; static double duration_s; static struct timespec start; static atomic_int ready=0,go=0; 
static double now_ns(){struct timespec t;clock_gettime(CLOCK_MONOTONIC_RAW,&t);return (double)t.tv_sec*1e9+t.tv_nsec;}
static struct timespec mono_now(){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t;}
static struct timespec plus_ns(struct timespec t,int64_t ns){int64_t v=(int64_t)t.tv_nsec+ns;t.tv_sec+=v/NS;t.tv_nsec=v%NS;if(t.tv_nsec<0){t.tv_nsec+=NS;t.tv_sec--;}return t;}
static int64_t diff_ns(struct timespec a,struct timespec b){return (a.tv_sec-b.tv_sec)*NS+(a.tv_nsec-b.tv_nsec);}
static uint64_t rng(uint64_t *s){uint64_t x=*s;x^=x>>12;x^=x<<25;x^=x>>27;*s=x;return x*2685821657736338717ULL;}
static double uniform(uint64_t *s){return ((rng(s)>>11)+0.5)/9007199254740992.0;}
static double bounded_laplace(uint64_t *s,double center,double low,double high,unsigned long *attempts,unsigned long *fallbacks){const double b=640.0; if(low>=high)return center; for(int k=0;k<100000;k++){(*attempts)++;double u=uniform(s)-0.5;double x=center-b*copysign(log1p(-2*fabs(u)),u);if(x>=low&&x<=high)return x;} (*fallbacks)++; /* emergency fallback only: invert truncated CDF instead */
/* P(X<=x) = 0.5 exp((x-center)/b) below center, else 1-0.5 exp(-(x-center)/b) */
double fl=(low<center)?0.5*exp((low-center)/b):1-0.5*exp(-(low-center)/b);double fh=(high<center)?0.5*exp((high-center)/b):1-0.5*exp(-(high-center)/b);double p=fl+uniform(s)*(fh-fl);return p<0.5?center+b*log(2*p):center-b*log(2*(1-p));}
static void *worker(void *p){struct task *t=p; cpu_set_t cp;CPU_ZERO(&cp);CPU_SET(cpu,&cp);if(pthread_setaffinity_np(pthread_self(),sizeof(cp),&cp)){fprintf(stderr,"affinity error\n");return NULL;}struct sched_param sp={.sched_priority=80-t->rank};int rc=pthread_setschedparam(pthread_self(),SCHED_FIFO,&sp);if(rc){fprintf(stderr,"SCHED_FIFO failed: %s; run as root\n",strerror(rc));return NULL;}uint64_t state=0x9e3779b97f4a7c15ULL+((uint64_t)t->id<<32)+mode*99;atomic_fetch_add(&ready,1);while(!atomic_load(&go)){struct timespec w={0,1000000};nanosleep(&w,NULL);}struct timespec next=start;struct timespec stop=plus_ns(start,(int64_t)(duration_s*1e9));while(diff_ns(stop,next)>0){clock_nanosleep(CLOCK_MONOTONIC,TIMER_ABSTIME,&next,NULL);double target=(double)t->C*1e6;double begun=now_ns();uint64_t v=t->work_sink;do{for(int j=0;j<100;j++)v=(v*1664525U+1013904223U);}while(now_ns()-begun<target);t->work_sink=v;struct timespec finish=mono_now();t->jobs++;if(diff_ns(finish,next)>(int64_t)(t->T*1e6))t->miss++;double inter=t->T;if(mode){double a=now_ns();double lo=mode==1?t->epslo:fmax(t->epslo,t->T-t->delta);double hi=mode==1?t->epshi:fmin(t->epshi,t->T+t->delta);inter=bounded_laplace(&state,t->T,lo,hi,&t->attempts,&t->fallbacks);double b=now_ns();t->rand_ns+=b-a;t->rand_calls++;}next=plus_ns(next,(int64_t)llround(inter*1e6));if(diff_ns(next,finish)<0){/* Preserve releases; no silent dropping */}}return NULL;}
int main(int argc,char**argv){if(argc<5){fprintf(stderr,"usage: benchmark INPUT.csv MODE(TS|DPS|SARTS) duration_sec cpu\n");return 2;}const char*nm=argv[2];mode=!strcmp(nm,"TS")?0:!strcmp(nm,"DPS")?1:!strcmp(nm,"SARTS")?2:-1;if(mode<0)return 2;duration_s=atof(argv[3]);cpu=atoi(argv[4]);FILE*f=fopen(argv[1],"r");if(!f){perror(argv[1]);return 2;}char line[1024];fgets(line,sizeof(line),f);while(fgets(line,sizeof(line),f)&&n<MAX_TASKS){struct task*t=&tasks[n];if(sscanf(line,"%d,%lf,%lf,%lf,%lf,%lf",&t->id,&t->C,&t->T,&t->epslo,&t->epshi,&t->delta)!=6)continue;t->rank=n;n++;}fclose(f);if(!n){fprintf(stderr,"no tasks\n");return 2;}for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)if(tasks[j].T<tasks[i].T){struct task temp=tasks[i];tasks[i]=tasks[j];tasks[j]=temp;}for(int i=0;i<n;i++)tasks[i].rank=i;
for(int i=0;i<n;i++){if(pthread_create(&tasks[i].thread,NULL,worker,&tasks[i])){perror("pthread_create");return 2;}}struct timespec wait_start=mono_now();while(atomic_load(&ready)<n){struct timespec now=mono_now();if(diff_ns(now,wait_start)>2*NS){fprintf(stderr,"threads failed real-time initialization\n");return 3;}usleep(1000);}start=plus_ns(mono_now(),200000000LL);atomic_store(&go,1);for(int i=0;i<n;i++)pthread_join(tasks[i].thread,NULL);unsigned long jobs=0,miss=0,calls=0,attempts=0,fallbacks=0;double rand_ns=0;for(int i=0;i<n;i++){jobs+=tasks[i].jobs;miss+=tasks[i].miss;calls+=tasks[i].rand_calls;attempts+=tasks[i].attempts;fallbacks+=tasks[i].fallbacks;rand_ns+=tasks[i].rand_ns;}printf("scheduler,jobs,deadline_misses,randomization_calls,randomization_mean_us,sampling_attempts,attempts_per_call,fallback_calls\n%s,%lu,%lu,%lu,%.9f,%lu,%.6f,%lu\n",nm,jobs,miss,calls,calls?rand_ns/calls/1000.0:0.0,attempts,calls?(double)attempts/calls:0.0,fallbacks);return 0;}
