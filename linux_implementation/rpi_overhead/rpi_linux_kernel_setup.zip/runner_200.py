#!/usr/bin/env python3
"""Two-pass Raspberry Pi benchmark, exactly 200 n=10 U=0.5 task sets, five trials.
Collects four metric families for DPS and SARTS only:
  context switches per completed job; pick_task_rt() time;
  randomization time; PMIC rail-power (performance / ondemand).
No PREEMPT_RT kernel source modifications are made.
"""
import csv
import math
import os
from pathlib import Path
import re
import shutil
import statistics
import subprocess
import time

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'task_parameters_200.csv'
OUTPUT = ROOT / 'results_200'
MODE = os.environ.get('PASS', 'plain').strip()
if MODE not in ('plain', 'trace'):
    raise SystemExit('PASS must be plain or trace')
DRY_RUN = os.environ.get('DRY_RUN', '0') == '1'
DURATION = float(os.environ.get('DURATION', '60'))
TRIALS = int(os.environ.get('TRIALS', '5'))
CPU = int(os.environ.get('CPU', '1'))
INTERVAL = float(os.environ.get('SAMPLE_INTERVAL', '0.2'))
POLICIES = ('DPS', 'SARTS')
GOVS = ('performance', 'ondemand') if MODE == 'plain' else ('performance',)
TARGET_N = 10
TARGET_U = 0.5
COUNT = 200
CPU_GOV = Path(f'/sys/devices/system/cpu/cpu{CPU}/cpufreq/scaling_governor')
BASE_COLUMNS = ('n_tasks', 'utilization', 'taskset_id', 'task_id', 'C_ms', 'T_ms',
                'eps_low_ms', 'eps_high_ms', 'sarts_delta_ms')


def load_tasksets():
    if not DATA.exists():
        raise SystemExit(f'Missing {DATA}. Supply 200 independently generated task sets; existing 10-set CSV is insufficient.')
    with DATA.open(newline='') as fh:
        reader = csv.DictReader(fh)
        missing = set(BASE_COLUMNS) - set(reader.fieldnames or ())
        if missing:
            raise SystemExit(f'Missing required input columns: {sorted(missing)}')
        raw = list(reader)
    groups = {}
    for p in raw:
        if int(p['n_tasks']) != TARGET_N or not math.isclose(float(p['utilization']), TARGET_U, abs_tol=1e-7):
            continue
        sid = str(p['taskset_id']).strip()
        groups.setdefault(sid, []).append(p)
    if len(groups) != COUNT:
        raise SystemExit(f'Expected exactly {COUNT} unique task sets at n={TARGET_N}, U={TARGET_U}; found {len(groups)}. No runs started.')
    for sid, tasks in groups.items():
        if len(tasks) != TARGET_N or len({str(x['task_id']) for x in tasks}) != TARGET_N:
            raise SystemExit(f'Task set {sid}: expected 10 distinct task rows; found {len(tasks)} rows.')
        for p in tasks:
            c, t, lo, hi, delta = (float(p[k]) for k in ('C_ms','T_ms','eps_low_ms','eps_high_ms','sarts_delta_ms'))
            if not all(math.isfinite(x) for x in (c,t,lo,hi,delta)):
                raise SystemExit(f'Task set {sid}: non-finite parameters')
            if not (0 < c <= t and 0 < lo < hi and delta >= 0):
                raise SystemExit(f'Task set {sid}: invalid execution, period or perturbation bounds')
            if max(lo, t-delta) >= min(hi,t+delta):
                raise SystemExit(f'Task set {sid}: empty SARTS perturbation interval')
    return dict(sorted(groups.items(), key=lambda pair: int(pair[0])))


def command(args):
    return subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)


def pmic_power():
    if not shutil.which('vcgencmd'):
        return None
    r = command(['vcgencmd', 'pmic_read_adc'])
    if r.returncode:
        return None
    vals = {}
    for line in r.stdout.splitlines():
        m = re.search(r'^\s*([\w]+)\s+(current|volt)\(\d+\)=([0-9.]+)([AV])', line)
        if m:
            vals[(m[1],m[2])] = float(m[3])
    total = 0.0
    matched = 0
    for (rail, kind), current in vals.items():
        if kind != 'current':
            continue
        other = rail[:-2] + '_V' if rail.endswith('_A') else rail.replace('A','V')
        volt = vals.get((other,'volt'))
        if volt is not None:
            total += current * volt
            matched += 1
    return total if matched else None


def parse_trace(report):
    switches = sum(': sched_switch:' in ln and 'pi_benchmark' in ln for ln in report.splitlines())
    times = []
    for ln in report.splitlines():
        if 'pick_task_rt();' not in ln:
            continue
        m = re.search(r'([0-9.]+) us\s*\|\s*pick_task_rt\(\);', ln)
        if m:
            times.append(float(m.group(1)))
    return switches, times


def benchmark_record(stdout):
    # trace-cmd record normally forwards the child program's CSV stdout.
    lines = stdout.splitlines()
    for i, line in enumerate(lines):
        if line.strip().startswith('scheduler,jobs,deadline_misses,'):
            if i+1 >= len(lines):
                break
            rows = list(csv.DictReader([lines[i], lines[i+1]]))
            if len(rows) == 1:
                return rows[0]
    raise RuntimeError('Missing benchmark CSV output. Cannot compute context switches per completed job from the same traced run.')


def get_rows(path):
    if not path.exists():
        return []
    with path.open(newline='') as fh:
        return list(csv.DictReader(fh))


def save_rows(path, rows):
    if not rows:
        return
    tmp = path.with_suffix('.tmp')
    with tmp.open('w', newline='') as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    tmp.replace(path)


def main():
    tasksets = load_tasksets()
    expected = COUNT * TRIALS * len(POLICIES) * len(GOVS)
    print(f'Valid input: {len(tasksets)} task sets, {TRIALS} trials, {POLICIES}; {MODE} pass: {expected} configurations', flush=True)
    if DURATION <= 0 or TRIALS <= 0 or INTERVAL <= 0:
        raise SystemExit('DURATION, TRIALS, and SAMPLE_INTERVAL must be positive')
    if DRY_RUN:
        print('DRY_RUN: validated CSV and experiment counts; no experiments executed.')
        return
    if os.geteuid() != 0:
        raise SystemExit('Run experiments with sudo -E')
    if MODE == 'trace' and not shutil.which('trace-cmd'):
        raise SystemExit('trace-cmd missing')
    if not CPU_GOV.exists():
        raise SystemExit(f'CPU governor sysfs missing: {CPU_GOV}')
    if not (ROOT / 'pi_benchmark').exists():
        raise SystemExit('Compiled pi_benchmark is missing')
    outdir = OUTPUT / MODE
    outdir.mkdir(parents=True, exist_ok=True)
    aggregate = outdir / ('runtime_all.csv' if MODE == 'plain' else 'trace_all.csv')
    rows = get_rows(aggregate)
    def key(r): return (r['governor'],str(r['taskset_id']),str(r['trial']),r['scheduler'])
    done = {key(r) for r in rows}
    original = CPU_GOV.read_text().strip()
    try:
        for gov in GOVS:
            CPU_GOV.write_text(gov)
            if CPU_GOV.read_text().strip() != gov:
                raise RuntimeError(f'Governor failed to change to {gov}')
            for sid, tasks in tasksets.items():
                tfile = outdir / f'taskset_{int(sid):04d}.csv'
                if not tfile.exists():
                    with tfile.open('w',newline='') as fh:
                        writer = csv.writer(fh)
                        writer.writerow(('id','C_ms','T_ms','eps_low_ms','eps_high_ms','sarts_delta_ms'))
                        for p in tasks:
                            writer.writerow([p[k] for k in ('task_id','C_ms','T_ms','eps_low_ms','eps_high_ms','sarts_delta_ms')])
                for trial in range(1,TRIALS+1):
                    for policy in POLICIES:
                        rec_key = (gov,sid,str(trial),policy)
                        if rec_key in done:
                            continue
                        slug = f'{gov}_set{int(sid):04d}_trial{trial:02d}_{policy}'
                        benchmark = [str(ROOT/'pi_benchmark'),str(tfile),policy,str(DURATION),str(CPU)]
                        tracefile = outdir / (slug + '.dat')
                        args = (['trace-cmd','record','-M',str(1<<CPU),'-p','function_graph',
                                 '-g','pick_task_rt','-e','sched:sched_switch','-o',str(tracefile)] + benchmark) if MODE=='trace' else benchmark
                        print(f'{MODE.upper()} {slug}',flush=True)
                        samples=[]
                        start=time.monotonic()
                        proc=subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                        while proc.poll() is None:
                            if MODE == 'plain':
                                value=pmic_power()
                                if value is not None:
                                    samples.append(value)
                            time.sleep(INTERVAL)
                        stdout, stderr=proc.communicate()
                        elapsed=time.monotonic()-start
                        (outdir/(slug+'.csv')).write_text(stdout)
                        (outdir/(slug+'.stderr.txt')).write_text(stderr)
                        if proc.returncode:
                            raise RuntimeError(f'{slug} failed (return code {proc.returncode}): {stderr[-1500:]}')
                        b=benchmark_record(stdout)
                        if b['scheduler'] != policy:
                            raise RuntimeError(f'Scheduler mismatch in {slug}')
                        jobs=int(b['jobs'])
                        if jobs <= 0:
                            raise RuntimeError(f'No completed jobs for {slug}')
                        if MODE == 'plain':
                            if not samples:
                                raise RuntimeError(f'No PMIC samples for {slug}')
                            record={'governor':gov,'taskset_id':sid,'trial':trial,'scheduler':policy,
                                    'elapsed_s':elapsed,'completed_jobs':jobs,
                                    'randomization_mean_us':b['randomization_mean_us'],
                                    'pmic_rail_W':statistics.mean(samples),'pmic_samples':len(samples)}
                        else:
                            report=command(['trace-cmd','report','-i',str(tracefile)])
                            if report.returncode:
                                raise RuntimeError(f'Trace report failed for {slug}: {report.stderr[-1500:]}')
                            switches, times=parse_trace(report.stdout)
                            if not times or switches <= 0:
                                raise RuntimeError(f'Incomplete trace for {slug}: switches={switches}, function calls={len(times)}')
                            record={'governor':gov,'taskset_id':sid,'trial':trial,'scheduler':policy,
                                    'completed_jobs':jobs,'benchmark_involved_switches':switches,
                                    'context_switches_per_job':switches/jobs,
                                    'pick_task_rt_mean_us':statistics.mean(times),
                                    'pick_task_rt_calls':len(times)}
                        rows.append(record)
                        done.add(rec_key)
                        save_rows(aggregate,rows)
                        print(f'  saved {len(rows)}/{expected}',flush=True)
    finally:
        try: CPU_GOV.write_text(original)
        except OSError: pass
    print(f'{MODE} pass complete. Output: {aggregate}')


if __name__ == '__main__':
    main()
