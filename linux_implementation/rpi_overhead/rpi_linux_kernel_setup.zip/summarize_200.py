#!/usr/bin/env python3
"""Summarize four metric families over 200 task-set means (five trials each)."""
import csv
from collections import defaultdict
from pathlib import Path
import statistics
ROOT=Path(__file__).resolve().parent/'results_200'

def read(name):
    p=ROOT/name
    if not p.exists():
        raise SystemExit(f'Missing {p}')
    with p.open(newline='') as fh:
        return list(csv.DictReader(fh))

plain=read('plain/runtime_all.csv')
trace=read('trace/trace_all.csv')
policies=('DPS','SARTS')
expected_plain=200*5*2*2
expected_trace=200*5*2

def check(rows, expected, governors, name):
    keys=[(r['taskset_id'],r['trial'],r['scheduler'],r['governor']) for r in rows]
    if len(rows) != expected or len(set(keys)) != expected:
        raise SystemExit(f'{name}: expected {expected} unique records, found {len(rows)} rows and {len(set(keys))} unique keys')
    if len({r['taskset_id'] for r in rows}) != 200:
        raise SystemExit(f'{name}: not exactly 200 task sets')
    for r in rows:
        if r['scheduler'] not in policies or r['governor'] not in governors:
            raise SystemExit(f'{name}: unexpected scheduler/governor')
    for sid in {r['taskset_id'] for r in rows}:
        for policy in policies:
            for gov in governors:
                trials={int(r['trial']) for r in rows if r['taskset_id']==sid and r['scheduler']==policy and r['governor']==gov}
                if trials != set(range(1,6)):
                    raise SystemExit(f'{name}: missing trials for set {sid}, {policy}, {gov}: {trials}')
check(plain,expected_plain,('performance','ondemand'),'plain')
check(trace,expected_trace,('performance',),'trace')

metrics=[
 ('context_switches_per_completed_job',trace,'performance','context_switches_per_job'),
 ('pick_task_rt_mean_us',trace,'performance','pick_task_rt_mean_us'),
 ('randomization_mean_us',plain,'performance','randomization_mean_us'),
 ('pmic_power_performance_W',plain,'performance','pmic_rail_W'),
 ('pmic_power_ondemand_W',plain,'ondemand','pmic_rail_W'),
]
summary=[]
for title, rows, gov, field in metrics:
    output={'measurement':title}
    for policy in policies:
        by_set=defaultdict(list)
        for r in rows:
            if r['governor']==gov and r['scheduler']==policy:
                if not r[field]: raise SystemExit(f'Missing {field} in {policy}, taskset {r["taskset_id"]}')
                by_set[r['taskset_id']].append(float(r[field]))
        taskset_means=[statistics.mean(values) for values in by_set.values()]
        output[f'{policy}_mean']=f'{statistics.mean(taskset_means):.6f}'
        output[f'{policy}_sd']=f'{statistics.stdev(taskset_means):.6f}'
    summary.append(output)
ROOT.mkdir(exist_ok=True)
out=ROOT/'four_metric_summary.csv'
with out.open('w',newline='') as fh:
    writer=csv.DictWriter(fh,fieldnames=('measurement','DPS_mean','DPS_sd','SARTS_mean','SARTS_sd'))
    writer.writeheader();writer.writerows(summary)
print(out)
print(out.read_text())
